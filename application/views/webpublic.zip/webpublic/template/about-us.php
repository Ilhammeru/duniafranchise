        
        <div class="row">

        	<h1>Tentang Kami</h1>
        	<p><?php echo $aboutUs['content'];?></p>

        </div>
