    
    <div class="error-page" style="text-align: center">
        <h1 style="color:#f0ad4e; font-weight: 800; font-size: 200px"> 404</h1>

        <div class="error-content">
        <h3><i class="fa fa-warning text-yellow"></i> Oops! Page not found.</h3>

        <p>
        We could not find the page you were looking for.
        Meanwhile, you may <a href="<?=base_url('home');?>">return to dashboard</a>.
        </p>

        </div>
        <!-- /.error-content -->
    </div>
    <!-- /.error-page -->
