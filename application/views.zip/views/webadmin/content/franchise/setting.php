    <style>
    .custom-switch {
        padding-left: 2.25rem;
    }
    .custom-control {
        position: relative;
        z-index: 1;
        display: inline-block;
        min-height: 1.5rem;
        -webkit-print-color-adjust: exact;
        color-adjust: exact;
    }input[type=checkbox], input[type=radio] {
        box-sizing: border-box;
        padding: 0;
    }

    .custom-control-input {
        position: absolute;
        left: 0;
        z-index: -1;
        width: 1rem;
        height: 1.25rem;
        opacity: 0;
    }
    label:not(.form-check-label):not(.custom-file-label) {
        font-weight: 700;
    }

    .custom-control-label {
        position: relative;
        margin-bottom: 0;
        vertical-align: top;
    }
    .custom-control-input:checked~.custom-control-label::before {
        color: #fff;
        border-color: #007bff;
        background-color: #007bff;
        box-shadow: none;
    }

    .custom-switch .custom-control-label::before {
        left: -2.25rem;
        width: 1.75rem;
        pointer-events: all;
        border-radius: .5rem;
    }
    .custom-control-label::before, .custom-file-label, .custom-select {
        transition: background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }
    .custom-control-label::before {
        position: absolute;
        top: .5rem;
        left: -1.5rem;
        display: block;
        width: 1rem;
        height: 1rem;
        pointer-events: none;
        content: "";
        background-color: #dee2e6;
        border: #adb5bd solid 1px;
        box-shadow: inset 0 0.25rem 0.25rem rgb(0 0 0 / 10%);
    }
    .custom-switch .custom-control-input:checked~.custom-control-label::after {
        background-color: #dee2e6;
        -webkit-transform: translateX(.75rem);
        transform: translateX(.75rem);
    }

    .custom-switch .custom-control-label::after {
        top: calc(.25rem + 4px);
        left: calc(-2.25rem + 2px);
        width: calc(1rem - 4px);
        height: calc(1rem - 4px);
        background-color: #adb5bd;
        border-radius: .5rem;
        transition: background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-transform .15s ease-in-out;
        transition: transform .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
        transition: transform .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-transform .15s ease-in-out;
    }
    .custom-control-label::after {
        position: absolute;
        top: .25rem;
        left: -1.5rem;
        display: block;
        width: 1rem;
        height: 1rem;
        content: "";
        background: 50%/50% 50% no-repeat;
    }
    </style>

    <div class="content-wrapper">

		<ol class="breadcrumb">

			<?php echo $homeLink;?>

			<?php echo $linkMenu;?>
			
			<?php echo $sublinkMenu;?>

		</ol>

		<section class="invoice">

			<div class="row">

				<div class="col-xs-12">

					<h2 class="page-header">
                        <div class="custom-control custom-switch">
                            <input type="checkbox" class="custom-control-input" id="customSwitch1">
                            <label class="custom-control-label" for="customSwitch1"> <?php echo $subtitleMenu;?></label>
                        </div>
					</h2>

				</div>
				<!-- /.col-xs-12 -->

			</div>
			<!-- /.row -->

            <div class="row">

                <div class="col-md-12">
                    <button class="btn btn-setting btn-deep-sky-blue" id="btn-attr" data-id="attr">Attribute</button>
                    <button class="btn btn-setting btn-white-lilac" id="btn-media" data-id="media">Media</button>
                    <button class="btn btn-setting btn-white-lilac" id="btn-chat" data-id="chat">Chat</button>
                    <button class="btn btn-setting btn-white-lilac" id="btn-detail" data-id="detail">Detail Franchise</button>
                    <button class="btn btn-setting btn-white-lilac" id="btn-join" data-id="join">Join Franchise</button>
                </div>

            </div>

        </section>

        <div class="col-md-6" style="padding: 0">

            <section class="invoice box-setting" id="box-attr">
                
                <h2 class="page-header">Attribute</h2>

                <div class="row">

                    <div class="col-md-4">
                        Decsription
                        <hr style="padding:0; margin:0">
                    </div>

                    <div class="col-md-8">
                        <textarea rows="2" class="form-control" rows="3" id="inputFranchiseText" onchange="updateFranchise()"><?=$franchise['text'];?></textarea>
                    </div>
                </div>

                <br>

                <div class="row">

                    <div class="col-md-4">
                        Hits | DF
                        <hr style="padding:0; margin:0">
                    </div>

                    <div class="col-md-8">
                        <input type="text" class="form-control" value="<?php echo $franchise['hits'];?>" id="inputFranchiseHits" onchange="updateFranchise()">
                    </div>
                </div>

            </section>

            <section class="invoice box-setting" id="box-media" style="display: none">
                
                <h2 class="page-header">Media</h2>
            </section>

            <section class="invoice box-setting" id="box-chat" style="display: none">
                
                <h2 class="page-header">Chat</h2>
            </section>

            <section class="invoice box-setting" id="box-detail" style="display: none">
                
                <h2 class="page-header">Detail Franchise</h2>
            </section>

            <section class="invoice box-setting" id="box-join" style="display: none">
                
                <h2 class="page-header">Join Franchise</h2>
            </section>
        </div>

        <section>

    <script>

        $('.btn-setting').on('click', function () {

            var attr = $(this).data('id');

            $('.box-setting').hide();
            $('#box-' + attr).css('display', 'block');

            $('.btn-setting').removeClass('btn-deep-sky-blue').removeClass('btn-white-lilac').addClass('btn-white-lilac');
            $('#btn-' + attr).removeClass('btn-white-lilac').addClass('btn-deep-sky-blue');
        });

    </script>