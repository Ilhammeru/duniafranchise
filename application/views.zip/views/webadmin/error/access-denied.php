
	<center>

	<h1>Error: Access Denied</h1>

	<p>
		<a href="<?=site_url('dashboard');?>">Back to Dashboard</a>
	</p>

	</center>

</section>

</div>